package com.example.aviatoraiscanner

import android.content.Context
import org.json.JSONArray

object RoundStore {
    private const val PREFS = "aviator_local_data"
    private const val KEY_ROUNDS = "rounds"

    @Synchronized
    fun add(context: Context, value: Float) {
        if (!value.isFinite() || value < 1f) return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = JSONArray(prefs.getString(KEY_ROUNDS, "[]") ?: "[]")
        current.put(value.toDouble())
        // Keep the most recent 5,000 results to avoid unbounded storage.
        val trimmed = JSONArray()
        val start = (current.length() - 5000).coerceAtLeast(0)
        for (i in start until current.length()) trimmed.put(current.getDouble(i))
        prefs.edit().putString(KEY_ROUNDS, trimmed.toString()).apply()
    }

    @Synchronized
    fun getAll(context: Context): List<Float> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ROUNDS, "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).mapNotNull { i ->
            array.optDouble(i).takeIf { it.isFinite() && it >= 1.0 }?.toFloat()
        }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove(KEY_ROUNDS).apply()
    }
}
