package com.example.aviatoraiscanner

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var statusView: TextView
    private lateinit var historyView: TextView
    private lateinit var statsView: TextView
    private lateinit var manualInput: EditText

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
                }
                startForegroundService(serviceIntent)
                statusView.text = "Scanner running. Android is sharing your screen."
            } else {
                statusView.text = "Screen capture permission was not granted."
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshHistory()
    }

    override fun onResume() {
        super.onResume()
        if (::historyView.isInitialized) refreshHistory()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
            setBackgroundColor(0xFFF4F5F7.toInt())
        }
        scroll.addView(page)

        val title = TextView(this).apply {
            text = "✈  AVIATOR AI SCANNER"
            textSize = 23f
            setTextColor(0xFF20242A.toInt())
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWrap())

        val intro = TextView(this).apply {
            text = "Offline multiplier reader & statistics"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
            setTextColor(0xFF626A73.toInt())
        }
        page.addView(intro, matchWrap())

        statusView = TextView(this).apply {
            text = "Scanner not running"
            textSize = 15f
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFE5E9EF.toInt())
        }
        page.addView(statusView, matchWrap())

        page.addView(makeButton("START SCREEN SCANNER") { requestScreenCapture() }, matchWrap())
        page.addView(makeButton("STOP SCANNER") {
            stopService(Intent(this, ScreenCaptureService::class.java))
            statusView.text = "Scanner stopped."
        }, matchWrap())

        val divider = TextView(this).apply {
            text = "MANUAL ENTRY"
            textSize = 16f
            setTextColor(0xFF20242A.toInt())
            setPadding(0, 26, 0, 8)
        }
        page.addView(divider, matchWrap())

        manualInput = EditText(this).apply {
            hint = "Enter multiplier, e.g. 2.45"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or
                android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        page.addView(manualInput, matchWrap())
        page.addView(makeButton("SAVE MULTIPLIER") {
            val value = manualInput.text.toString().trim().replace(',', '.').toFloatOrNull()
            if (value == null || value < 1f) {
                Toast.makeText(this, "Enter a valid multiplier of 1.00 or higher.", Toast.LENGTH_SHORT).show()
            } else {
                RoundStore.add(this, value)
                manualInput.text.clear()
                refreshHistory()
            }
        }, matchWrap())

        val statsTitle = TextView(this).apply {
            text = "HISTORICAL STATISTICS"
            textSize = 16f
            setTextColor(0xFF20242A.toInt())
            setPadding(0, 26, 0, 8)
        }
        page.addView(statsTitle, matchWrap())

        statsView = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFF303840.toInt())
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(statsView, matchWrap())

        val historyTitle = TextView(this).apply {
            text = "RECENT ROUNDS"
            textSize = 16f
            setTextColor(0xFF20242A.toInt())
            setPadding(0, 26, 0, 8)
        }
        page.addView(historyTitle, matchWrap())

        historyView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF303840.toInt())
            setPadding(18, 18, 18, 18)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        page.addView(historyView, matchWrap())

        page.addView(makeButton("CLEAR ALL HISTORY") {
            RoundStore.clear(this)
            refreshHistory()
        }, matchWrap())

        val disclaimer = TextView(this).apply {
            text = "Important: past rounds do not predict the next crash. This app only records visible results and calculates historical frequencies. It cannot guarantee wins or identify future crash points."
            textSize = 12f
            setTextColor(0xFF6A7078.toInt())
            setPadding(4, 24, 4, 16)
        }
        page.addView(disclaimer, matchWrap())

        setContentView(scroll)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun refreshHistory() {
        val rounds = RoundStore.getAll(this)
        val total = rounds.size
        val low = rounds.count { it < 2f }
        val mid = rounds.count { it >= 2f && it < 5f }
        val high = rounds.count { it >= 5f }

        statsView.text = if (total == 0) {
            "No rounds saved yet.\nStart screen scanning or enter a multiplier manually."
        } else {
            val p1 = low * 100.0 / total
            val p2 = mid * 100.0 / total
            val p3 = high * 100.0 / total
            "Total rounds: $total\nBelow 2x: ${"%.1f".format(p1)}%\n2x to 4.99x: ${"%.1f".format(p2)}%\n5x or above: ${"%.1f".format(p3)}%"
        }

        historyView.text = if (rounds.isEmpty()) "No results recorded." else
            rounds.takeLast(30).asReversed().mapIndexed { index, value ->
                "${index + 1}. ${"%.2f".format(value)}x"
            }.joinToString("\n")
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )
}
