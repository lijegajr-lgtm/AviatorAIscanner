# Aviator AI Scanner (offline Android starter)

This is a native Kotlin Android starter project. It stores results locally on the device and uses the bundled Google ML Kit Latin text-recognition model to look for visible multipliers.

## Features
- Manual multiplier entry.
- Local history and frequency statistics.
- User-approved Android MediaProjection screen capture.
- On-device OCR; no AI/cloud account is required.
- Foreground notification while screen capture is active.

## Important limitations
- This is a starter project, not a prebuilt APK.
- OCR is experimental: it looks for text matching a number followed by `x` or `×`. It may miss results or read unrelated text elsewhere on screen.
- It does not know or predict future crash points. Historical frequencies are descriptive only.
- Some apps or devices may block screen capture or show a black screen.
- Screen capture can include private information. Start it only when the game is visible and stop it when finished.
- It does not interact with the game, place bets, bypass protections, or automate gambling.

## Build
Open this folder in an Android Gradle-compatible IDE, sync Gradle, then build the debug APK. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35, and ML Kit text recognition 16.0.1.

A compatible Android SDK and JDK 17 are required. This archive does not include the Android SDK, Gradle wrapper, or a compiled APK.

## First test
1. Install the debug APK on your Android phone.
2. Open the app and tap **START SCREEN SCANNER**.
3. Approve Android's screen-sharing prompt.
4. Switch to the Aviator game and keep the multiplier visible.
5. Return to the scanner to review the saved history.
6. Stop the scanner using the app's **STOP SCANNER** button.

If OCR records incorrect values, use manual entry for now. The next development task should be improving OCR with a selectable capture region and round-state validation.
